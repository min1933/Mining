#!/bin/bash
# For more usage info: hellminer --help

# Example SSL URL
# ./hellminer -c stratum+ssl://na.luckpool.net:3958 -u ADDRESS.WORKER -p x --cpu 1

./hellminer -c stratum+tcp://sg.vipor.net:5040 -u RXGhLDzjXgwr3cLMMFNXigucz2vCW1v87p.Priawiners -p x --cpu 4
